﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniversityManagementSystemWebApplication.Models
{
    public class Day
    {
        public int DayId { set; get; }
        public string Name { set; get; }
    }
}